# Waypoint — Mini Social Media Platform

CodeAlpha Full Stack Development Internship — Task 2

A small social feed: profiles, posts with photos, comments, likes,
and a follow system, backed by a Node.js + Express API.

## Stack

- **Frontend:** HTML, CSS, vanilla JavaScript (no framework/build step)
- **Backend:** Node.js + Express
- **Auth:** JWT (jsonwebtoken) + password hashing (bcryptjs)
- **Database:** a JSON file (`data/db.json`) accessed through
  `data/store.js` — same pattern as the e-commerce project, so it's
  runnable with zero external services.

## Features

- **Profiles** — name, bio, post/follower/following counts
  (`profile.html`)
- **Posts** — text (up to 500 chars) + optional photo URL, feed
  sorted newest-first, delete your own posts (`index.html`)
- **Comments** — reply on a post's detail page (`post.html`)
- **Likes** — toggle like on any post, count updates live
- **Follow system** — follow/unfollow from a profile; a "Following"
  tab on the feed shows only posts from people you follow

## Project structure

```
social-app/
├── server.js
├── data/
│   ├── db.json              # users, posts, comments, follows
│   └── store.js               # readDB()/writeDB() helpers
├── middleware/
│   └── auth.js                 # requireAuth + optionalAuth (feed works logged-out too)
├── routes/
│   ├── auth.js                  # POST /api/auth/register, /login
│   ├── users.js                  # GET /api/users/:id, POST /api/users/:id/follow
│   └── posts.js                   # posts, likes, comments
└── public/
    ├── index.html, post.html, profile.html, login.html, register.html
    ├── css/style.css
    └── js/ (api.js, main.js, post-card.js, feed.js, post.js, profile.js, auth.js)
```

## Running it locally

```bash
npm install
npm start
```

Then open **http://localhost:4001** (a different port from the
e-commerce project, so you can run both at once).

## API reference

| Method | Route                     | Auth      | Description                                   |
|--------|----------------------------|-----------|-------------------------------------------------|
| POST   | /api/auth/register           | No        | Create account, returns JWT                     |
| POST   | /api/auth/login                | No        | Log in, returns JWT                             |
| GET    | /api/users/:id                   | Optional  | Profile + follower/following/post counts        |
| POST   | /api/users/:id/follow              | Yes       | Toggle follow for the current user              |
| GET    | /api/posts                           | Optional  | Feed (`?feed=following`, `?userId=`)            |
| GET    | /api/posts/:id                         | Optional  | Single post + its comments                      |
| POST   | /api/posts                               | Yes       | Create a post (`text`, `image`)                 |
| DELETE | /api/posts/:id                             | Yes       | Delete your own post (and its comments)         |
| POST   | /api/posts/:id/like                          | Yes       | Toggle like                                     |
| POST   | /api/posts/:id/comments                        | Yes       | Add a comment                                   |

## Notes on the demo data

`data/db.json` ships with one seed user and post just so the feed
isn't empty on first run — that seed account's password hash is a
placeholder and can't actually be logged into. Register a real
account through the UI to try posting, liking, commenting and
following.

## What to do before submitting to CodeAlpha

1. Push this to a GitHub repo named `CodeAlpha_SocialMediaApp` (the
   PDF's convention is `CodeAlpha_ProjectName`).
2. Record a short walkthrough video: register two accounts (in two
   browser tabs, or one normal + one incognito), post from one,
   follow, like, and comment from the other, then show the
   "Following" tab filtering the feed.
3. Post on LinkedIn tagging @CodeAlpha with the video and repo link.
4. Submit via the internship's submission form.

You've now got 2 of the 4 tasks done, which already meets the
internship's minimum for a completion certificate — Task 1
(e-commerce store) and this one.
