function handleAuthForm(formId, endpoint) {
  const form = document.getElementById(formId);
  if (!form) return;

  const errorEl = document.getElementById('form-error');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.style.display = 'none';

    const body = {};
    new FormData(form).forEach((value, key) => (body[key] = value));

    try {
      const data = await api(endpoint, { method: 'POST', body });
      localStorage.setItem('wp_token', data.token);
      localStorage.setItem('wp_user', JSON.stringify(data.user));
      window.location.href = 'index.html';
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.style.display = 'block';
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  handleAuthForm('login-form', '/auth/login');
  handleAuthForm('register-form', '/auth/register');
});
