document.addEventListener('DOMContentLoaded', async () => {
  const headerEl = document.getElementById('profile-header');
  const feedEl = document.getElementById('profile-feed');
  if (!headerEl) return;

  const id = new URLSearchParams(window.location.search).get('id');

  try {
    const user = await api(`/users/${id}`);
    document.title = `${user.name} — Waypoint`;

    headerEl.innerHTML = `
      <h1>${escapeHtml(user.name)}</h1>
      ${user.bio ? `<p class="profile-bio">${escapeHtml(user.bio)}</p>` : ''}
      <div class="profile-stats">
        <span><strong>${user.postCount}</strong> posts</span>
        <span><strong>${user.followerCount}</strong> followers</span>
        <span><strong>${user.followingCount}</strong> following</span>
      </div>
      ${
        user.isSelf
          ? ''
          : getCurrentUser()
          ? `<button class="btn btn-outline ${user.isFollowing ? 'following' : ''}" id="follow-btn">
              ${user.isFollowing ? 'Following' : 'Follow'}
            </button>`
          : `<a class="btn btn-outline" href="login.html">Log in to follow</a>`
      }
    `;

    const followBtn = document.getElementById('follow-btn');
    if (followBtn) {
      followBtn.addEventListener('click', async () => {
        try {
          const result = await api(`/users/${id}/follow`, { method: 'POST' });
          followBtn.textContent = result.following ? 'Following' : 'Follow';
          followBtn.classList.toggle('following', result.following);
        } catch (err) {
          showToast(err.message);
        }
      });
    }

    const posts = await api(`/posts?userId=${id}`);
    feedEl.innerHTML =
      posts.length === 0
        ? `<p class="empty-note">No posts yet.</p>`
        : posts.map(postCardHtml).join('');
    attachPostCardHandlers(feedEl);
  } catch (err) {
    headerEl.innerHTML = `<p class="empty-note">${err.message}</p>`;
  }
});
