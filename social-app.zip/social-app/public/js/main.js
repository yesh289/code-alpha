function renderNav() {
  const accountEl = document.getElementById('nav-account');
  if (!accountEl) return;

  const user = getCurrentUser();
  if (user) {
    accountEl.innerHTML = `
      <a href="profile.html?id=${user.id}">Profile</a>
      <a href="#" id="logout-link">Log out</a>
    `;
    document.getElementById('logout-link').addEventListener('click', (e) => {
      e.preventDefault();
      logout();
    });
  } else {
    accountEl.innerHTML = `<a href="login.html">Log in</a>`;
  }
}

document.addEventListener('DOMContentLoaded', renderNav);
