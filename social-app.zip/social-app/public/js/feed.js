document.addEventListener('DOMContentLoaded', () => {
  const feedEl = document.getElementById('feed');
  if (!feedEl) return;

  const composer = document.getElementById('composer');
  const textInput = document.getElementById('post-text');
  const imageInput = document.getElementById('post-image');
  const charCount = document.getElementById('char-count');
  const postBtn = document.getElementById('post-btn');
  const tabs = document.querySelectorAll('.feed-tabs button');

  let activeTab = 'all';

  if (!getCurrentUser() && composer) {
    composer.style.display = 'none';
  }

  if (textInput) {
    textInput.addEventListener('input', () => {
      charCount.textContent = `${textInput.value.length}/500`;
      postBtn.disabled = textInput.value.trim().length === 0;
    });
  }

  if (postBtn) {
    postBtn.addEventListener('click', async () => {
      try {
        postBtn.disabled = true;
        await api('/posts', {
          method: 'POST',
          body: { text: textInput.value, image: imageInput.value },
        });
        textInput.value = '';
        imageInput.value = '';
        charCount.textContent = '0/500';
        loadFeed();
      } catch (err) {
        showToast(err.message);
        postBtn.disabled = false;
      }
    });
  }

  tabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      activeTab = tab.dataset.tab;
      tabs.forEach((t) => t.classList.toggle('active', t === tab));
      loadFeed();
    });
  });

  async function loadFeed() {
    feedEl.innerHTML = `<p class="empty-note">Loading…</p>`;
    try {
      const query = activeTab === 'following' ? '?feed=following' : '';
      const posts = await api(`/posts${query}`);
      if (posts.length === 0) {
        feedEl.innerHTML =
          activeTab === 'following'
            ? `<p class="empty-note">Follow a few people to see their posts here.</p>`
            : `<p class="empty-note">No posts yet — be the first to share something.</p>`;
        return;
      }
      feedEl.innerHTML = posts.map(postCardHtml).join('');
      attachPostCardHandlers(feedEl);
    } catch (err) {
      feedEl.innerHTML = `<p class="empty-note">${err.message}</p>`;
    }
  }

  loadFeed();
});
