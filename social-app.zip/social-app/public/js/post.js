document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('post-detail');
  if (!container) return;

  const id = new URLSearchParams(window.location.search).get('id');

  async function load() {
    try {
      const p = await api(`/posts/${id}`);
      document.title = `${p.author.name} on Waypoint`;

      container.innerHTML = `
        ${postCardHtml(p)}
        <div class="comment-list" id="comment-list">
          ${
            p.comments.length === 0
              ? `<p class="empty-note">No comments yet.</p>`
              : p.comments
                  .map(
                    (c) => `
              <div class="comment">
                <div>
                  <span class="author">${escapeHtml(c.author.name)}</span>${escapeHtml(c.text)}
                  <span class="time">${timeAgo(c.createdAt)}</span>
                </div>
              </div>`
                  )
                  .join('')
          }
        </div>
        ${
          getCurrentUser()
            ? `
          <form class="comment-form" id="comment-form">
            <input type="text" id="comment-input" placeholder="Write a comment…" maxlength="300" required>
            <button class="btn" type="submit">Reply</button>
          </form>`
            : `<p class="form-note"><a href="login.html">Log in</a> to comment.</p>`
        }
      `;

      attachPostCardHandlers(container, {
        onDeleted: () => {
          window.location.href = 'index.html';
        },
      });

      const form = document.getElementById('comment-form');
      if (form) {
        form.addEventListener('submit', async (e) => {
          e.preventDefault();
          const input = document.getElementById('comment-input');
          try {
            await api(`/posts/${id}/comments`, { method: 'POST', body: { text: input.value } });
            input.value = '';
            load();
          } catch (err) {
            showToast(err.message);
          }
        });
      }
    } catch (err) {
      container.innerHTML = `<p class="empty-note">${err.message}</p>`;
    }
  }

  load();
});
