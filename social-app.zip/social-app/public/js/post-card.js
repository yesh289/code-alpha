function postCardHtml(p) {
  const user = getCurrentUser();
  return `
    <div class="post-card" data-id="${p.id}">
      <div class="post-head">
        <div>
          <a class="post-author" href="profile.html?id=${p.author.id}">${escapeHtml(p.author.name)}</a>
          <div class="post-time">${timeAgo(p.createdAt)}</div>
        </div>
        ${p.isMine ? `<button class="post-delete" data-action="delete">Delete</button>` : ''}
      </div>
      <p class="post-text">${escapeHtml(p.text)}</p>
      ${p.image ? `<div class="post-image"><img src="${p.image}" alt=""></div>` : ''}
      <div class="post-actions">
        <button data-action="like" class="${p.likedByMe ? 'liked' : ''}">
          ♥ <span class="like-count">${p.likeCount}</span>
        </button>
        <a href="post.html?id=${p.id}">💬 ${p.commentCount}</a>
      </div>
    </div>
  `;
}

function attachPostCardHandlers(container, { onDeleted } = {}) {
  container.querySelectorAll('.post-card').forEach((card) => {
    const id = Number(card.dataset.id);

    const likeBtn = card.querySelector('[data-action="like"]');
    likeBtn.addEventListener('click', async () => {
      if (!getCurrentUser()) {
        window.location.href = 'login.html';
        return;
      }
      try {
        const result = await api(`/posts/${id}/like`, { method: 'POST' });
        likeBtn.classList.toggle('liked', result.liked);
        likeBtn.querySelector('.like-count').textContent = result.likeCount;
      } catch (err) {
        showToast(err.message);
      }
    });

    const deleteBtn = card.querySelector('[data-action="delete"]');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', async () => {
        if (!confirm('Delete this post?')) return;
        try {
          await api(`/posts/${id}`, { method: 'DELETE' });
          card.remove();
          if (onDeleted) onDeleted(id);
        } catch (err) {
          showToast(err.message);
        }
      });
    }
  });
}
