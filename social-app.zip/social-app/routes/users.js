const express = require('express');
const { readDB, writeDB } = require('../data/store');
const { requireAuth, optionalAuth } = require('../middleware/auth');

const router = express.Router();

function publicUser(u) {
  return { id: u.id, name: u.name, bio: u.bio };
}

// GET /api/users/:id  - profile + follower/following counts
router.get('/:id', optionalAuth, (req, res) => {
  const db = readDB();
  const userId = Number(req.params.id);
  const user = db.users.find((u) => u.id === userId);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  const followerCount = db.follows.filter((f) => f.followingId === userId).length;
  const followingCount = db.follows.filter((f) => f.followerId === userId).length;
  const postCount = db.posts.filter((p) => p.userId === userId).length;
  const isFollowing = req.user
    ? db.follows.some((f) => f.followerId === req.user.id && f.followingId === userId)
    : false;

  res.json({
    ...publicUser(user),
    followerCount,
    followingCount,
    postCount,
    isFollowing,
    isSelf: req.user ? req.user.id === userId : false,
  });
});

// POST /api/users/:id/follow  - toggle follow for the current user
router.post('/:id/follow', requireAuth, (req, res) => {
  const targetId = Number(req.params.id);
  if (targetId === req.user.id) {
    return res.status(400).json({ error: "You can't follow yourself." });
  }

  const db = readDB();
  if (!db.users.find((u) => u.id === targetId)) {
    return res.status(404).json({ error: 'User not found.' });
  }

  const existingIndex = db.follows.findIndex(
    (f) => f.followerId === req.user.id && f.followingId === targetId
  );

  let following;
  if (existingIndex >= 0) {
    db.follows.splice(existingIndex, 1);
    following = false;
  } else {
    db.follows.push({ followerId: req.user.id, followingId: targetId });
    following = true;
  }
  writeDB(db);

  res.json({ following });
});

module.exports = router;
