const express = require('express');
const { readDB, writeDB } = require('../data/store');
const { requireAuth, optionalAuth } = require('../middleware/auth');

const router = express.Router();

function serializePost(post, db, currentUserId) {
  const author = db.users.find((u) => u.id === post.userId);
  const commentCount = db.comments.filter((c) => c.postId === post.id).length;
  return {
    id: post.id,
    text: post.text,
    image: post.image || null,
    createdAt: post.createdAt,
    author: author ? { id: author.id, name: author.name } : { id: post.userId, name: 'Deleted user' },
    likeCount: post.likes.length,
    likedByMe: currentUserId ? post.likes.includes(currentUserId) : false,
    commentCount,
    isMine: currentUserId === post.userId,
  };
}

// GET /api/posts?feed=following|all&userId=
router.get('/', optionalAuth, (req, res) => {
  const { feed, userId } = req.query;
  const db = readDB();
  let posts = db.posts;

  if (userId) {
    posts = posts.filter((p) => p.userId === Number(userId));
  } else if (feed === 'following') {
    if (!req.user) {
      return res.status(401).json({ error: 'Log in to see posts from people you follow.' });
    }
    const followingIds = db.follows
      .filter((f) => f.followerId === req.user.id)
      .map((f) => f.followingId);
    posts = posts.filter((p) => followingIds.includes(p.userId));
  }

  posts = [...posts].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(posts.map((p) => serializePost(p, db, req.user && req.user.id)));
});

// GET /api/posts/:id  - single post + its comments
router.get('/:id', optionalAuth, (req, res) => {
  const db = readDB();
  const post = db.posts.find((p) => p.id === Number(req.params.id));
  if (!post) return res.status(404).json({ error: 'Post not found.' });

  const comments = db.comments
    .filter((c) => c.postId === post.id)
    .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
    .map((c) => {
      const author = db.users.find((u) => u.id === c.userId);
      return {
        id: c.id,
        text: c.text,
        createdAt: c.createdAt,
        author: author ? { id: author.id, name: author.name } : { id: c.userId, name: 'Deleted user' },
      };
    });

  res.json({ ...serializePost(post, db, req.user && req.user.id), comments });
});

// POST /api/posts  body: { text, image }
router.post('/', requireAuth, (req, res) => {
  const { text, image } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'Write something before posting.' });
  }
  if (text.length > 500) {
    return res.status(400).json({ error: 'Posts are limited to 500 characters.' });
  }

  const db = readDB();
  const post = {
    id: db.nextPostId++,
    userId: req.user.id,
    text: text.trim(),
    image: image ? image.trim() : null,
    createdAt: new Date().toISOString(),
    likes: [],
  };
  db.posts.push(post);
  writeDB(db);

  res.status(201).json(serializePost(post, db, req.user.id));
});

// DELETE /api/posts/:id  - only the author can delete
router.delete('/:id', requireAuth, (req, res) => {
  const db = readDB();
  const post = db.posts.find((p) => p.id === Number(req.params.id));
  if (!post) return res.status(404).json({ error: 'Post not found.' });
  if (post.userId !== req.user.id) {
    return res.status(403).json({ error: 'You can only delete your own posts.' });
  }

  db.posts = db.posts.filter((p) => p.id !== post.id);
  db.comments = db.comments.filter((c) => c.postId !== post.id);
  writeDB(db);
  res.status(204).end();
});

// POST /api/posts/:id/like  - toggle like
router.post('/:id/like', requireAuth, (req, res) => {
  const db = readDB();
  const post = db.posts.find((p) => p.id === Number(req.params.id));
  if (!post) return res.status(404).json({ error: 'Post not found.' });

  const idx = post.likes.indexOf(req.user.id);
  let liked;
  if (idx >= 0) {
    post.likes.splice(idx, 1);
    liked = false;
  } else {
    post.likes.push(req.user.id);
    liked = true;
  }
  writeDB(db);

  res.json({ liked, likeCount: post.likes.length });
});

// POST /api/posts/:id/comments  body: { text }
router.post('/:id/comments', requireAuth, (req, res) => {
  const { text } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'Comment cannot be empty.' });
  }

  const db = readDB();
  const post = db.posts.find((p) => p.id === Number(req.params.id));
  if (!post) return res.status(404).json({ error: 'Post not found.' });

  const comment = {
    id: db.nextCommentId++,
    postId: post.id,
    userId: req.user.id,
    text: text.trim(),
    createdAt: new Date().toISOString(),
  };
  db.comments.push(comment);
  writeDB(db);

  res.status(201).json({
    id: comment.id,
    text: comment.text,
    createdAt: comment.createdAt,
    author: { id: req.user.id, name: req.user.name },
  });
});

module.exports = router;
