const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'codealpha-dev-secret-change-me';

function getTokenPayload(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return null;
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (err) {
    return null;
  }
}

// Blocks the request if there's no valid token.
function requireAuth(req, res, next) {
  const payload = getTokenPayload(req);
  if (!payload) {
    return res.status(401).json({ error: 'Please log in to continue.' });
  }
  req.user = payload;
  next();
}

// Attaches req.user if a valid token is present, but never blocks -
// used for routes like the feed that work for logged-out visitors too,
// but personalize (e.g. "liked by me") when a user is signed in.
function optionalAuth(req, res, next) {
  req.user = getTokenPayload(req);
  next();
}

module.exports = { requireAuth, optionalAuth, JWT_SECRET };
