import { useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';

const ICE_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

// Manages the Socket.io signaling connection plus one RTCPeerConnection per
// remote participant (mesh topology — fine for small group calls).
export default function useWebRTC(roomId, localStream, token) {
  const socketRef = useRef(null);
  const peersRef = useRef(new Map()); // socketId -> RTCPeerConnection
  const [remoteStreams, setRemoteStreams] = useState([]); // [{ socketId, user, stream }]
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!localStream || !roomId || !token) return;

    const socket = io(import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000', {
      auth: { token },
    });
    socketRef.current = socket;

    function createPeerConnection(peerSocketId, remoteUser) {
      const pc = new RTCPeerConnection(ICE_SERVERS);

      localStream.getTracks().forEach((track) => pc.addTrack(track, localStream));

      pc.onicecandidate = (event) => {
        if (event.candidate) {
          socket.emit('webrtc:ice-candidate', { to: peerSocketId, candidate: event.candidate });
        }
      };

      pc.ontrack = (event) => {
        setRemoteStreams((prev) => {
          const existing = prev.find((r) => r.socketId === peerSocketId);
          if (existing) {
            existing.stream = event.streams[0];
            return [...prev];
          }
          return [...prev, { socketId: peerSocketId, user: remoteUser, stream: event.streams[0] }];
        });
      };

      peersRef.current.set(peerSocketId, pc);
      return pc;
    }

    socket.on('connect', () => {
      setConnected(true);
      socket.emit('room:join', roomId);
    });

    // We're the newcomer: initiate an offer to each existing participant
    socket.on('room:existing-participants', async (participants) => {
      for (const { socketId, user } of participants) {
        const pc = createPeerConnection(socketId, user);
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        socket.emit('webrtc:offer', { to: socketId, offer });
      }
    });

    // Someone else joined after us: wait for their offer, just track them for UI
    socket.on('room:user-joined', ({ socketId, user }) => {
      setRemoteStreams((prev) =>
        prev.some((r) => r.socketId === socketId) ? prev : [...prev, { socketId, user, stream: null }]
      );
    });

    socket.on('webrtc:offer', async ({ from, offer, user }) => {
      const pc = createPeerConnection(from, user);
      await pc.setRemoteDescription(new RTCSessionDescription(offer));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      socket.emit('webrtc:answer', { to: from, answer });
    });

    socket.on('webrtc:answer', async ({ from, answer }) => {
      const pc = peersRef.current.get(from);
      if (pc) await pc.setRemoteDescription(new RTCSessionDescription(answer));
    });

    socket.on('webrtc:ice-candidate', async ({ from, candidate }) => {
      const pc = peersRef.current.get(from);
      if (pc && candidate) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(candidate));
        } catch (err) {
          console.error('Error adding ICE candidate', err);
        }
      }
    });

    socket.on('room:user-left', ({ socketId }) => {
      const pc = peersRef.current.get(socketId);
      if (pc) pc.close();
      peersRef.current.delete(socketId);
      setRemoteStreams((prev) => prev.filter((r) => r.socketId !== socketId));
    });

    return () => {
      peersRef.current.forEach((pc) => pc.close());
      peersRef.current.clear();
      socket.disconnect();
      setConnected(false);
      setRemoteStreams([]);
    };
  }, [roomId, localStream, token]);

  return { socket: socketRef, peers: peersRef, remoteStreams, connected };
}
