import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';

export default function Home() {
  const [roomName, setRoomName] = useState('');
  const [joinCode, setJoinCode] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      const { data } = await api.post('/rooms', { name: roomName || 'Untitled Room' });
      navigate(`/room/${data.roomId}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create room');
    }
  };

  const handleJoin = async (e) => {
    e.preventDefault();
    if (!joinCode.trim()) return;
    try {
      await api.get(`/rooms/${joinCode.trim()}`);
      navigate(`/room/${joinCode.trim()}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Room not found');
    }
  };

  return (
    <div className="home-grid">
      <div className="auth-card">
        <h2>Start a new meeting</h2>
        {error && <div className="alert-error">{error}</div>}
        <form onSubmit={handleCreate}>
          <input
            placeholder="Meeting name (optional)"
            value={roomName}
            onChange={(e) => setRoomName(e.target.value)}
          />
          <button className="btn btn-primary" type="submit">Create Room</button>
        </form>
      </div>

      <div className="auth-card">
        <h2>Join a meeting</h2>
        <form onSubmit={handleJoin}>
          <input
            placeholder="Enter room code"
            value={joinCode}
            onChange={(e) => setJoinCode(e.target.value)}
          />
          <button className="btn btn-outline" type="submit">Join Room</button>
        </form>
      </div>

      <p className="muted center-msg">
        Video &amp; audio, screen sharing, a shared whiteboard, file sharing, and live chat —
        all in one room. Share the room code with others to invite them.
      </p>
    </div>
  );
}
