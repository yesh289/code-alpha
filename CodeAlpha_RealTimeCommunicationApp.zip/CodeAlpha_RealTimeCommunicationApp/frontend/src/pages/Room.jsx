import React, { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import VideoTile from '../components/VideoTile.jsx';
import Whiteboard from '../components/Whiteboard.jsx';
import Chat from '../components/Chat.jsx';
import FileShare from '../components/FileShare.jsx';
import useWebRTC from '../hooks/useWebRTC.js';
import { useAuth } from '../context/AuthContext.jsx';

const TABS = ['Whiteboard', 'Chat', 'Files'];

export default function Room() {
  const { roomId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const [localStream, setLocalStream] = useState(null);
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);
  const [screenSharing, setScreenSharing] = useState(false);
  const [activeTab, setActiveTab] = useState('Whiteboard');
  const [error, setError] = useState('');
  const cameraTrackRef = useRef(null);

  useEffect(() => {
    let stream;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        cameraTrackRef.current = stream.getVideoTracks()[0];
        setLocalStream(stream);
      } catch (err) {
        setError('Could not access camera/microphone. Please grant permission and reload.');
      }
    })();

    return () => {
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const { socket, peers, remoteStreams, connected } = useWebRTC(roomId, localStream, token);

  const toggleMic = () => {
    localStream?.getAudioTracks().forEach((t) => (t.enabled = !t.enabled));
    setMicOn((v) => !v);
  };

  const toggleCam = () => {
    localStream?.getVideoTracks().forEach((t) => (t.enabled = !t.enabled));
    setCamOn((v) => !v);
  };

  const replaceOutgoingTrack = (newTrack) => {
    peers.current.forEach((pc) => {
      const sender = pc.getSenders().find((s) => s.track && s.track.kind === 'video');
      if (sender) sender.replaceTrack(newTrack);
    });
  };

  const startScreenShare = async () => {
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const screenTrack = screenStream.getVideoTracks()[0];
      replaceOutgoingTrack(screenTrack);
      setLocalStream((prev) => {
        const combined = new MediaStream([screenTrack, ...prev.getAudioTracks()]);
        return combined;
      });
      setScreenSharing(true);
      socket.current?.emit('screen:share-started', { roomId });

      screenTrack.onended = () => stopScreenShare();
    } catch (err) {
      // user cancelled the share prompt — no need to surface an error
    }
  };

  const stopScreenShare = () => {
    if (cameraTrackRef.current) {
      replaceOutgoingTrack(cameraTrackRef.current);
      setLocalStream((prev) => new MediaStream([cameraTrackRef.current, ...prev.getAudioTracks()]));
    }
    setScreenSharing(false);
    socket.current?.emit('screen:share-stopped', { roomId });
  };

  const handleLeave = () => {
    localStream?.getTracks().forEach((t) => t.stop());
    navigate('/');
  };

  const copyRoomCode = () => {
    navigator.clipboard.writeText(roomId);
  };

  return (
    <div className="room-layout">
      <div className="room-header">
        <div>
          <strong>Room:</strong> {roomId}{' '}
          <button className="btn btn-outline small" onClick={copyRoomCode}>Copy code</button>
        </div>
        <span className={`status-dot ${connected ? 'online' : 'offline'}`}>
          {connected ? 'Connected' : 'Connecting...'}
        </span>
      </div>

      {error && <div className="alert-error">{error}</div>}

      <div className="room-body">
        <div className="video-grid">
          <VideoTile stream={localStream} label={`You (${user?.name})`} muted isSelf />
          {remoteStreams.map((r) => (
            <VideoTile key={r.socketId} stream={r.stream} label={r.user?.name || 'Participant'} />
          ))}
        </div>

        <div className="side-panel">
          <div className="tabs">
            {TABS.map((t) => (
              <button
                key={t}
                className={`tab ${activeTab === t ? 'active' : ''}`}
                onClick={() => setActiveTab(t)}
              >
                {t}
              </button>
            ))}
          </div>
          {activeTab === 'Whiteboard' && <Whiteboard roomId={roomId} socket={socket} />}
          {activeTab === 'Chat' && <Chat roomId={roomId} socket={socket} />}
          {activeTab === 'Files' && <FileShare roomId={roomId} socket={socket} />}
        </div>
      </div>

      <div className="controls-bar">
        <button className={`btn ${micOn ? 'btn-outline' : 'btn-danger'}`} onClick={toggleMic}>
          {micOn ? '🎙 Mute' : '🔇 Unmute'}
        </button>
        <button className={`btn ${camOn ? 'btn-outline' : 'btn-danger'}`} onClick={toggleCam}>
          {camOn ? '📷 Camera Off' : '📷 Camera On'}
        </button>
        <button
          className="btn btn-outline"
          onClick={screenSharing ? stopScreenShare : startScreenShare}
        >
          {screenSharing ? '🛑 Stop Sharing' : '🖥 Share Screen'}
        </button>
        <button className="btn btn-danger" onClick={handleLeave}>Leave</button>
      </div>
    </div>
  );
}
