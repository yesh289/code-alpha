import React, { useEffect, useState } from 'react';

const MAX_SIZE_MB = 5; // keep demo file transfers small since they go through the signaling server

export default function FileShare({ roomId, socket }) {
  const [files, setFiles] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!socket?.current) return;
    const s = socket.current;
    const handler = (file) => setFiles((prev) => [...prev, file]);
    s.on('file:share', handler);
    return () => s.off('file:share', handler);
  }, [socket]);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setError('');

    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      setError(`File too large — keep it under ${MAX_SIZE_MB}MB for this demo.`);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      socket.current?.emit('file:share', {
        roomId,
        fileName: file.name,
        fileType: file.type,
        data: reader.result, // base64 data URL
      });
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  return (
    <div className="fileshare-panel">
      <label className="btn btn-outline file-input-label">
        Share a file
        <input type="file" onChange={handleFileChange} hidden />
      </label>
      {error && <div className="alert-error">{error}</div>}
      <div className="file-list">
        {files.length === 0 && <p className="muted">No files shared yet.</p>}
        {files.map((f, i) => (
          <a key={i} href={f.data} download={f.fileName} className="file-item">
            📎 {f.fileName} <span className="muted">from {f.from}</span>
          </a>
        ))}
      </div>
    </div>
  );
}
