import React, { useEffect, useRef } from 'react';

export default function VideoTile({ stream, label, muted = false, isSelf = false }) {
  const videoRef = useRef(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  return (
    <div className={`video-tile ${isSelf ? 'self' : ''}`}>
      {stream ? (
        <video ref={videoRef} autoPlay playsInline muted={muted} />
      ) : (
        <div className="video-placeholder">Connecting...</div>
      )}
      <span className="video-label">{label}</span>
    </div>
  );
}
