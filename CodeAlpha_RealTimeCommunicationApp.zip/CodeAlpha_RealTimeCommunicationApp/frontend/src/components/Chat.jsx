import React, { useEffect, useRef, useState } from 'react';

export default function Chat({ roomId, socket }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const listRef = useRef(null);

  useEffect(() => {
    if (!socket?.current) return;
    const s = socket.current;
    const handler = (msg) => setMessages((prev) => [...prev, msg]);
    s.on('chat:message', handler);
    return () => s.off('chat:message', handler);
  }, [socket]);

  useEffect(() => {
    listRef.current?.scrollTo(0, listRef.current.scrollHeight);
  }, [messages]);

  const send = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    socket.current?.emit('chat:message', { roomId, text });
    setText('');
  };

  return (
    <div className="chat-panel">
      <div className="chat-messages" ref={listRef}>
        {messages.length === 0 && <p className="muted">No messages yet. Say hi 👋</p>}
        {messages.map((m, i) => (
          <div key={i} className="chat-message">
            <strong>{m.user?.name}: </strong>
            <span>{m.text}</span>
          </div>
        ))}
      </div>
      <form className="chat-form" onSubmit={send}>
        <input
          placeholder="Type a message..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button className="btn btn-primary" type="submit">Send</button>
      </form>
    </div>
  );
}
