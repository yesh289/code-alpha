import React, { useEffect, useRef, useState } from 'react';

const COLORS = ['#e8e9ee', '#f87171', '#34d399', '#6c8cff', '#fbbf24'];

export default function Whiteboard({ roomId, socket }) {
  const canvasRef = useRef(null);
  const drawing = useRef(false);
  const lastPoint = useRef(null);
  const [color, setColor] = useState(COLORS[0]);

  const getCtx = () => canvasRef.current.getContext('2d');

  const drawLine = (x0, y0, x1, y1, strokeColor) => {
    const ctx = getCtx();
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1, y1);
    ctx.stroke();
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    const resize = () => {
      const { width, height } = canvas.parentElement.getBoundingClientRect();
      canvas.width = width;
      canvas.height = height;
    };
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, []);

  useEffect(() => {
    if (!socket?.current) return;
    const s = socket.current;

    const handleRemoteDraw = (stroke) => {
      drawLine(stroke.x0, stroke.y0, stroke.x1, stroke.y1, stroke.color);
    };
    const handleRemoteClear = () => {
      const ctx = getCtx();
      ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    };

    s.on('whiteboard:draw', handleRemoteDraw);
    s.on('whiteboard:clear', handleRemoteClear);
    return () => {
      s.off('whiteboard:draw', handleRemoteDraw);
      s.off('whiteboard:clear', handleRemoteClear);
    };
  }, [socket]);

  const getPos = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const handleDown = (e) => {
    drawing.current = true;
    lastPoint.current = getPos(e);
  };

  const handleMove = (e) => {
    if (!drawing.current) return;
    const { x, y } = getPos(e);
    const { x: x0, y: y0 } = lastPoint.current;
    drawLine(x0, y0, x, y, color);
    socket.current?.emit('whiteboard:draw', {
      roomId,
      stroke: { x0, y0, x1: x, y1: y, color },
    });
    lastPoint.current = { x, y };
  };

  const handleUp = () => {
    drawing.current = false;
  };

  const handleClear = () => {
    const ctx = getCtx();
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    socket.current?.emit('whiteboard:clear', { roomId });
  };

  return (
    <div className="whiteboard-wrapper">
      <div className="whiteboard-toolbar">
        {COLORS.map((c) => (
          <button
            key={c}
            className={`color-dot ${c === color ? 'active' : ''}`}
            style={{ background: c }}
            onClick={() => setColor(c)}
          />
        ))}
        <button className="btn btn-outline" onClick={handleClear}>Clear</button>
      </div>
      <canvas
        ref={canvasRef}
        className="whiteboard-canvas"
        onMouseDown={handleDown}
        onMouseMove={handleMove}
        onMouseUp={handleUp}
        onMouseLeave={handleUp}
      />
    </div>
  );
}
