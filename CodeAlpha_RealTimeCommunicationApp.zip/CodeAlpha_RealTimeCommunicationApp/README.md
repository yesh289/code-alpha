# CodeAlpha_RealTimeCommunicationApp

A full-stack real-time video conferencing & collaboration tool (Task 4 — CodeAlpha Full Stack
Development Internship). Built with **WebRTC** for peer-to-peer video/audio, **Socket.io** for
signaling and real-time collaboration, **React + Vite** on the frontend, and **Node.js + Express +
MongoDB** on the backend.

## Features (matches every bullet in the task brief)
- **Video calling (multi-user)** — mesh WebRTC: every participant connects directly to every other
  participant for audio/video.
- **Screen sharing** — swap your camera track for `getDisplayMedia()` output on the fly; stops
  automatically if you end the share from the browser's native "stop sharing" bar.
- **File sharing** — share small files instantly to everyone in the room (demo-friendly, capped at
  5MB since transfer goes through the signaling server).
- **Whiteboard** — a shared canvas; every stroke you draw is broadcast live to the rest of the room.
- **Data encryption** — WebRTC media (audio/video/screen) is encrypted end-to-end by the browser
  itself via mandatory DTLS-SRTP; on top of that, all signaling/API traffic should be served over
  HTTPS/WSS in production, and passwords are hashed with bcrypt, never stored in plain text.
- **User authentication** — JWT-based register/login, and the same JWT is used to authenticate the
  Socket.io connection before you can join a room.
- Bonus: live text **chat** in every room.

## Tech Stack
| Layer     | Tech |
|-----------|------|
| Frontend  | React 18, React Router, WebRTC, Socket.io-client, Vite |
| Backend   | Node.js, Express.js, Socket.io (signaling), Mongoose (MongoDB), JWT, bcrypt.js |
| Database  | MongoDB (users & room records) |

## Project Structure
```
CodeAlpha_RealTimeCommunicationApp/
├── backend/
│   ├── config/db.js
│   ├── models/         (User, Room)
│   ├── middleware/auth.js       (HTTP + Socket.io JWT auth)
│   ├── routes/          (auth, rooms)
│   └── server.js        (Express + Socket.io signaling server)
└── frontend/
    └── src/
        ├── api/axios.js
        ├── context/AuthContext.jsx
        ├── hooks/useWebRTC.js    (peer-connection + signaling logic)
        ├── pages/        (Login, Register, Home, Room)
        └── components/   (Navbar, VideoTile, Whiteboard, Chat, FileShare)
```

## How the real-time pieces fit together
- **Signaling**: the backend never touches audio/video itself — it only relays WebRTC `offer` /
  `answer` / `ice-candidate` messages between browsers over Socket.io so they can establish a
  direct peer-to-peer connection.
- **Room presence**: joining a room tells you who's already there (`room:existing-participants`)
  so you initiate offers to them; anyone joining after you triggers `room:user-joined` on your end.
- **Whiteboard / chat / files**: simple broadcast events scoped to the room (`whiteboard:draw`,
  `chat:message`, `file:share`) — every peer in the room receives them instantly.

## Setup & Run Locally

### Prerequisites
- Node.js 18+
- MongoDB running locally, or a free MongoDB Atlas connection string
- Two browser windows (or two devices) to actually test a call with yourself

### 1. Backend
```bash
cd backend
cp .env.example .env      # edit MONGO_URI / JWT_SECRET if needed
npm install
npm run dev                # starts on http://localhost:5000
```

### 2. Frontend
```bash
cd frontend
cp .env.example .env
npm install
npm run dev                # starts on http://localhost:5173
```

Open http://localhost:5173 in two browser windows (or one normal + one incognito), register two
different users, have one create a room and the other join with the room code, and allow camera/
mic access in both. You should see both video feeds, and can test screen share, the whiteboard,
chat, and file sharing live between the two windows.

> Note: getUserMedia/getDisplayMedia require a "secure context" — `localhost` is exempt from this,
> but if you deploy this, both frontend and backend need HTTPS.

## API Overview
| Method | Endpoint            | Description                      |
|--------|----------------------|-----------------------------------|
| POST   | /api/auth/register   | Register a new user              |
| POST   | /api/auth/login      | Log in, get JWT                  |
| GET    | /api/auth/me         | Current user (protected)         |
| POST   | /api/rooms           | Create a room, returns roomId    |
| GET    | /api/rooms/:roomId   | Check a room exists before joining |

Socket.io events (all require the JWT passed as `auth: { token }` on connect) are documented inline
in `backend/server.js` and `frontend/src/hooks/useWebRTC.js`.

## Notes for Submission
- Push this whole folder to a GitHub repo named `CodeAlpha_RealTimeCommunicationApp`.
- For the video walkthrough: two windows side by side is the most convincing demo — show the video
  call connecting, then screen share, then draw on the whiteboard and switch to chat, then share a
  file — all while it stays in sync on both screens.
- Post it on LinkedIn tagging @CodeAlpha with the GitHub link, per the internship instructions.
