require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const connectDB = require('./config/db');
const { socketAuth } = require('./middleware/auth');

const authRoutes = require('./routes/authRoutes');
const roomRoutes = require('./routes/roomRoutes');

connectDB();

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || '*' }));
app.use(express.json({ limit: '10mb' })); // allow small base64 file payloads

app.get('/', (req, res) => res.send('CodeAlpha Real-Time Communication App API is running'));
app.use('/api/auth', authRoutes);
app.use('/api/rooms', roomRoutes);

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: process.env.CLIENT_URL || '*' },
  maxHttpBufferSize: 10 * 1024 * 1024, // 10MB, generous enough for small file-sharing demo
});

// Every socket connection must present the same JWT issued at login
io.use(socketAuth);

// roomId -> Map<socketId, { id, name, email }>
const roomParticipants = new Map();

function getParticipants(roomId) {
  if (!roomParticipants.has(roomId)) roomParticipants.set(roomId, new Map());
  return roomParticipants.get(roomId);
}

io.on('connection', (socket) => {
  console.log(`Socket connected: ${socket.id} (${socket.user?.name})`);
  let currentRoom = null;

  // 1) Join a room -> tell the newcomer who's already there, tell everyone else about the newcomer
  socket.on('room:join', (roomId) => {
    currentRoom = roomId;
    socket.join(roomId);

    const participants = getParticipants(roomId);
    const existing = Array.from(participants.entries()).map(([socketId, user]) => ({
      socketId,
      user,
    }));

    participants.set(socket.id, {
      _id: socket.user._id,
      name: socket.user.name,
      email: socket.user.email,
    });

    socket.emit('room:existing-participants', existing);
    socket.to(roomId).emit('room:user-joined', {
      socketId: socket.id,
      user: participants.get(socket.id),
    });
  });

  // 2) WebRTC signaling relay (mesh: each pair of peers negotiates directly)
  socket.on('webrtc:offer', ({ to, offer }) => {
    io.to(to).emit('webrtc:offer', { from: socket.id, offer, user: socket.user });
  });

  socket.on('webrtc:answer', ({ to, answer }) => {
    io.to(to).emit('webrtc:answer', { from: socket.id, answer });
  });

  socket.on('webrtc:ice-candidate', ({ to, candidate }) => {
    io.to(to).emit('webrtc:ice-candidate', { from: socket.id, candidate });
  });

  // 3) Chat
  socket.on('chat:message', ({ roomId, text }) => {
    io.to(roomId).emit('chat:message', {
      text,
      user: { name: socket.user.name, _id: socket.user._id },
      at: new Date().toISOString(),
    });
  });

  // 4) Shared whiteboard — every draw stroke is broadcast to the rest of the room
  socket.on('whiteboard:draw', ({ roomId, stroke }) => {
    socket.to(roomId).emit('whiteboard:draw', stroke);
  });

  socket.on('whiteboard:clear', ({ roomId }) => {
    socket.to(roomId).emit('whiteboard:clear');
  });

  // 5) Lightweight file sharing (base64 payload, fine for small demo files)
  socket.on('file:share', ({ roomId, fileName, fileType, data }) => {
    io.to(roomId).emit('file:share', {
      fileName,
      fileType,
      data,
      from: socket.user.name,
      at: new Date().toISOString(),
    });
  });

  // 6) Screen share presence notifications (actual media renegotiates over WebRTC)
  socket.on('screen:share-started', ({ roomId }) => {
    socket.to(roomId).emit('screen:share-started', { socketId: socket.id, user: socket.user.name });
  });
  socket.on('screen:share-stopped', ({ roomId }) => {
    socket.to(roomId).emit('screen:share-stopped', { socketId: socket.id });
  });

  socket.on('disconnect', () => {
    if (currentRoom) {
      const participants = getParticipants(currentRoom);
      participants.delete(socket.id);
      socket.to(currentRoom).emit('room:user-left', { socketId: socket.id });
    }
    console.log(`Socket disconnected: ${socket.id}`);
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
