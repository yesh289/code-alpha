const express = require('express');
const { nanoid } = require('nanoid');
const Room = require('../models/Room');
const { protect } = require('../middleware/auth');

const router = express.Router();

// @route  POST /api/rooms   body: { name }  -> creates a new room, returns its roomId
router.post('/', protect, async (req, res) => {
  try {
    const roomId = nanoid(8);
    const room = await Room.create({
      roomId,
      name: req.body.name || 'Untitled Room',
      createdBy: req.user._id,
    });
    res.status(201).json(room);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// @route  GET /api/rooms/:roomId  -> check a room exists before joining
router.get('/:roomId', protect, async (req, res) => {
  try {
    const room = await Room.findOne({ roomId: req.params.roomId });
    if (!room) return res.status(404).json({ message: 'Room not found' });
    res.json(room);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
