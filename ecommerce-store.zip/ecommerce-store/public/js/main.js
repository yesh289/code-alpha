function renderNav() {
  const cartCountEl = document.getElementById('nav-cart-count');
  if (cartCountEl) {
    const count = cartItemCount();
    cartCountEl.textContent = count > 0 ? count : '';
    cartCountEl.style.display = count > 0 ? 'inline-block' : 'none';
  }

  const accountEl = document.getElementById('nav-account');
  if (!accountEl) return;

  const user = getCurrentUser();
  if (user) {
    accountEl.innerHTML = `
      <a href="orders.html">Orders</a>
      <a href="#" id="logout-link">Log out (${user.name.split(' ')[0]})</a>
    `;
    document.getElementById('logout-link').addEventListener('click', (e) => {
      e.preventDefault();
      logout();
    });
  } else {
    accountEl.innerHTML = `<a href="login.html">Log in</a>`;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  renderNav();

  const grid = document.getElementById('product-grid');
  if (!grid) return; // not on the home page

  let allProducts = [];
  let activeCategory = 'All';

  const chipsEl = document.getElementById('category-chips');
  const searchEl = document.getElementById('search-input');

  function render() {
    const term = (searchEl.value || '').toLowerCase();
    const filtered = allProducts.filter((p) => {
      const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
      const matchesSearch = !term || p.name.toLowerCase().includes(term);
      return matchesCategory && matchesSearch;
    });

    grid.innerHTML = filtered
      .map(
        (p) => `
      <a class="product-card" href="product.html?id=${p.id}">
        <div class="thumb"><img src="${p.image}" alt="${p.name}" loading="lazy"></div>
        <div class="info">
          <div class="category">${p.category}</div>
          <h3>${p.name}</h3>
          <div class="price">${formatPrice(p.price)}</div>
        </div>
      </a>`
      )
      .join('');

    if (filtered.length === 0) {
      grid.innerHTML = `<p class="empty-note">No products match that search.</p>`;
    }
  }

  function renderChips() {
    const categories = ['All', ...new Set(allProducts.map((p) => p.category))];
    chipsEl.innerHTML = categories
      .map(
        (c) => `<button class="chip ${c === activeCategory ? 'active' : ''}" data-category="${c}">${c}</button>`
      )
      .join('');

    chipsEl.querySelectorAll('.chip').forEach((btn) => {
      btn.addEventListener('click', () => {
        activeCategory = btn.dataset.category;
        renderChips();
        render();
      });
    });
  }

  api('/products')
    .then((products) => {
      allProducts = products;
      renderChips();
      render();
    })
    .catch(() => {
      grid.innerHTML = `<p class="empty-note">Could not load products. Is the server running?</p>`;
    });

  searchEl.addEventListener('input', render);
});
