document.addEventListener('DOMContentLoaded', async () => {
  const list = document.getElementById('orders-list');
  if (!list) return;

  if (!getCurrentUser()) {
    window.location.href = 'login.html?next=orders.html';
    return;
  }

  const placedId = new URLSearchParams(window.location.search).get('placed');

  try {
    const orders = await api('/orders');

    if (orders.length === 0) {
      list.innerHTML = `<p class="empty-note">No orders yet — <a href="index.html">start shopping</a>.</p>`;
      return;
    }

    list.innerHTML = orders
      .map(
        (o) => `
      <div class="order-card">
        <div class="order-head">
          <span>Order #${o.id} · ${new Date(o.createdAt).toLocaleDateString('en-IN', {
            day: 'numeric',
            month: 'short',
            year: 'numeric',
          })}</span>
          <span class="status-badge">${o.status}</span>
        </div>
        ${o.items
          .map(
            (item) => `
          <div class="order-line">
            <span>${item.name} × ${item.qty}</span>
            <span>${formatPrice(item.price * item.qty)}</span>
          </div>`
          )
          .join('')}
        <div class="order-total"><span>Total</span><span>${formatPrice(o.total)}</span></div>
      </div>`
      )
      .join('');

    if (placedId) {
      showToast(`Order #${placedId} placed successfully`);
    }
  } catch (err) {
    list.innerHTML = `<p class="empty-note">${err.message}</p>`;
  }
});
