// Small wrapper around fetch() so every call automatically sends the
// JWT (if the user is logged in) and throws a readable error message.

async function api(path, { method = 'GET', body } = {}) {
  const token = localStorage.getItem('fg_token');
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`/api${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || 'Something went wrong. Please try again.');
  }
  return data;
}

function getCurrentUser() {
  const raw = localStorage.getItem('fg_user');
  return raw ? JSON.parse(raw) : null;
}

function logout() {
  localStorage.removeItem('fg_token');
  localStorage.removeItem('fg_user');
  window.location.href = 'index.html';
}

function formatPrice(paise) {
  return `₹${paise.toLocaleString('en-IN')}`;
}

function showToast(message) {
  let toast = document.querySelector('.toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), 2200);
}
