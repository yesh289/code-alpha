document.addEventListener('DOMContentLoaded', async () => {
  const layout = document.getElementById('cart-layout');
  const linesEl = document.getElementById('cart-lines');
  const summaryEl = document.getElementById('cart-summary');
  const emptyEl = document.getElementById('cart-empty');
  if (!layout) return;

  let products = [];

  async function load() {
    const cart = getCart();
    if (cart.length === 0) {
      layout.style.display = 'none';
      emptyEl.style.display = 'block';
      return;
    }
    layout.style.display = 'grid';
    emptyEl.style.display = 'none';

    products = await api('/products');
    render(cart);
  }

  function render(cart) {
    let total = 0;

    linesEl.innerHTML = cart
      .map((item) => {
        const p = products.find((prod) => prod.id === item.productId);
        if (!p) return '';
        const lineTotal = p.price * item.qty;
        total += lineTotal;
        return `
          <div class="cart-line" data-id="${p.id}">
            <img src="${p.image}" alt="${p.name}">
            <div>
              <div class="name">${p.name}</div>
              <div class="unit-price">${formatPrice(p.price)} each</div>
            </div>
            <input type="number" min="1" max="${p.stock}" value="${item.qty}" class="qty-input">
            <div>
              <div>${formatPrice(lineTotal)}</div>
              <button class="remove">Remove</button>
            </div>
          </div>`;
      })
      .join('');

    summaryEl.innerHTML = `
      <div class="row"><span>Subtotal</span><span>${formatPrice(total)}</span></div>
      <div class="row"><span>Shipping</span><span>Free</span></div>
      <div class="row total"><span>Total</span><span>${formatPrice(total)}</span></div>
      <div class="field" style="margin-top:18px;">
        <label for="address">Delivery address</label>
        <textarea id="address" placeholder="House no, street, city, PIN"></textarea>
      </div>
      <div class="form-error" id="checkout-error"></div>
      <button class="btn btn-block" id="checkout-btn">Place order</button>
    `;

    linesEl.querySelectorAll('.qty-input').forEach((input) => {
      input.addEventListener('change', () => {
        const id = Number(input.closest('.cart-line').dataset.id);
        updateCartQty(id, Number(input.value));
        renderNav();
        render(getCart());
      });
    });

    linesEl.querySelectorAll('.remove').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = Number(btn.closest('.cart-line').dataset.id);
        removeFromCart(id);
        renderNav();
        load();
      });
    });

    document.getElementById('checkout-btn').addEventListener('click', () => checkout(cart));
  }

  async function checkout(cart) {
    const errorEl = document.getElementById('checkout-error');
    const address = document.getElementById('address').value.trim();
    errorEl.style.display = 'none';

    if (!getCurrentUser()) {
      window.location.href = 'login.html?next=cart.html';
      return;
    }
    if (!address) {
      errorEl.textContent = 'Please enter a delivery address.';
      errorEl.style.display = 'block';
      return;
    }

    try {
      const order = await api('/orders', {
        method: 'POST',
        body: {
          items: cart.map((i) => ({ productId: i.productId, qty: i.qty })),
          address,
        },
      });
      clearCart();
      window.location.href = `orders.html?placed=${order.id}`;
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.style.display = 'block';
    }
  }

  load();
});
