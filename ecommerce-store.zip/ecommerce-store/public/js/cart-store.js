// The cart lives in localStorage as an array of { productId, qty }.
// Product details (name/price/image) are always re-fetched from the
// server when needed, so the cart never trusts stale client-side prices.

function getCart() {
  const raw = localStorage.getItem('fg_cart');
  return raw ? JSON.parse(raw) : [];
}

function saveCart(cart) {
  localStorage.setItem('fg_cart', JSON.stringify(cart));
}

function addToCart(productId, qty) {
  const cart = getCart();
  const existing = cart.find((i) => i.productId === productId);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ productId, qty });
  }
  saveCart(cart);
}

function updateCartQty(productId, qty) {
  const cart = getCart();
  const item = cart.find((i) => i.productId === productId);
  if (item) item.qty = Math.max(1, qty);
  saveCart(cart);
}

function removeFromCart(productId) {
  saveCart(getCart().filter((i) => i.productId !== productId));
}

function clearCart() {
  localStorage.removeItem('fg_cart');
}

function cartItemCount() {
  return getCart().reduce((sum, i) => sum + i.qty, 0);
}
