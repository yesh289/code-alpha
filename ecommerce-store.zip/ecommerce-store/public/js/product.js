document.addEventListener('DOMContentLoaded', async () => {
  const id = new URLSearchParams(window.location.search).get('id');
  const container = document.getElementById('product-detail');
  if (!id || !container) return;

  try {
    const p = await api(`/products/${id}`);
    document.title = `${p.name} — Foundry Goods`;

    container.innerHTML = `
      <div class="photo"><img src="${p.image}" alt="${p.name}"></div>
      <div>
        <div class="category">${p.category}</div>
        <h1>${p.name}</h1>
        <div class="price">${formatPrice(p.price)}</div>
        <p class="description">${p.description}</p>
        <div class="qty-row">
          <label for="qty">Qty</label>
          <input type="number" id="qty" min="1" max="${p.stock}" value="1">
          <span class="stock-note">${p.stock} in stock</span>
        </div>
        <button class="btn" id="add-to-cart-btn" ${p.stock === 0 ? 'disabled' : ''}>
          ${p.stock === 0 ? 'Out of stock' : 'Add to cart'}
        </button>
      </div>
    `;

    document.getElementById('add-to-cart-btn').addEventListener('click', () => {
      const qty = Math.max(1, Number(document.getElementById('qty').value) || 1);
      addToCart(p.id, qty);
      renderNav();
      showToast(`Added ${p.name} to cart`);
    });
  } catch (err) {
    container.innerHTML = `<p class="empty-note">${err.message}</p>`;
  }
});
