# Foundry Goods — Simple E-commerce Store

CodeAlpha Full Stack Development Internship — Task 1

A small e-commerce store: product listings, product detail pages, a
cart, user registration/login, and order processing, backed by a
Node.js + Express API.

## Stack

- **Frontend:** HTML, CSS, vanilla JavaScript (no framework/build step)
- **Backend:** Node.js + Express
- **Auth:** JWT (jsonwebtoken) + password hashing (bcryptjs)
- **Database:** a JSON file (`data/db.json`) accessed through
  `data/store.js`. This keeps the project runnable with zero external
  services. Swapping in MongoDB or PostgreSQL later would only mean
  rewriting `store.js` — the routes call `readDB()`/`writeDB()` and
  don't care how the data is actually persisted.

## Features

- Product grid with category filter + search (`index.html`)
- Product detail page with quantity picker (`product.html`)
- Cart stored in the browser (`localStorage`), quantities editable,
  items removable (`cart.html`)
- Register / log in with JWT issued on success (`register.html`,
  `login.html`)
- Checkout creates an order via `POST /api/orders`. Prices and stock
  are always re-checked server-side from the database — the client
  only sends product IDs and quantities, never prices — so a tampered
  request can't change what gets charged
  - Order history page (`orders.html`)

## Project structure

```
ecommerce-store/
├── server.js              # Express app entry point
├── data/
│   ├── db.json             # products, users, orders (seed data included)
│   └── store.js             # readDB()/writeDB() helpers
├── middleware/
│   └── auth.js              # JWT verification middleware
├── routes/
│   ├── auth.js               # POST /api/auth/register, /login
│   ├── products.js           # GET /api/products, /api/products/:id
│   └── orders.js              # POST /api/orders, GET /api/orders
└── public/                  # static frontend
    ├── index.html, product.html, cart.html,
    │   login.html, register.html, orders.html
    ├── css/style.css
    └── js/ (api.js, cart-store.js, main.js, product.js, cart.js, auth.js, orders.js)
```

## Running it locally

```bash
npm install
npm start
```

Then open **http://localhost:4000** in your browser.

Optional: set a real JWT secret instead of the built-in default —

```bash
JWT_SECRET=your-long-random-string npm start
```

## API reference

| Method | Route                | Auth | Description                          |
|--------|-----------------------|------|---------------------------------------|
| GET    | /api/products          | No   | List products (`?category=`, `?q=`)   |
| GET    | /api/products/:id       | No   | Single product                        |
| POST   | /api/auth/register      | No   | Create account, returns JWT           |
| POST   | /api/auth/login          | No   | Log in, returns JWT                   |
| POST   | /api/orders               | Yes  | Place an order (`items`, `address`)   |
| GET    | /api/orders                | Yes  | Current user's order history          |

Authenticated requests send `Authorization: Bearer <token>`.

## What to do before submitting to CodeAlpha

The internship PDF asks for a few things beyond the code itself — none
of these are done for you, since they need to be genuinely yours:

1. **Create a GitHub repo** named `CodeAlpha_EcommerceStore` (or
   similar — the PDF's convention is `CodeAlpha_ProjectName`) and
   push this code to it.
2. **Record a short video** walking through the app — show the
   product grid, add something to the cart, register/log in, and
   place an order. Since you built this with me, walk through *why*
   each part works (e.g. "prices are recalculated on the server so
   the cart total can't be faked") — that's the kind of detail that
   makes the explanation convincing.
3. **Post on LinkedIn** tagging @CodeAlpha with the video and repo
   link, per the internship instructions.
4. **Submit via the internship's submission form** shared in your
   WhatsApp group.

## Possible extensions (if you want to go further)

- Move `data/db.json` to a real database (MongoDB with Mongoose is a
  natural next step and is explicitly suggested in the task brief).
- Add product images upload instead of hotlinked URLs.
- Add an admin view for managing stock.
- Add pagination to the product grid.
