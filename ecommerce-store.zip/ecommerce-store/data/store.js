// Minimal file-backed "database".
// For a learning project this keeps things transparent - no external DB
// server to install. Swapping this module for MongoDB/Postgres later
// would not require changing any route logic much, since it only
// exposes read/write helpers.

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'db.json');

function readDB() {
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(raw);
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

module.exports = { readDB, writeDB };
