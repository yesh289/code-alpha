const express = require('express');
const { readDB, writeDB } = require('../data/store');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// POST /api/orders  body: { items: [{ productId, qty }], address }
router.post('/', requireAuth, (req, res) => {
  const { items, address } = req.body;

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Your cart is empty.' });
  }
  if (!address || !address.trim()) {
    return res.status(400).json({ error: 'A delivery address is required.' });
  }

  const db = readDB();
  const lineItems = [];
  let total = 0;

  for (const { productId, qty } of items) {
    const product = db.products.find((p) => p.id === Number(productId));
    if (!product) {
      return res.status(400).json({ error: `Product ${productId} no longer exists.` });
    }
    const quantity = Math.max(1, Number(qty) || 1);
    if (product.stock < quantity) {
      return res.status(400).json({ error: `${product.name} only has ${product.stock} left in stock.` });
    }
    lineItems.push({
      productId: product.id,
      name: product.name,
      price: product.price,
      qty: quantity,
    });
    total += product.price * quantity;
  }

  // Prices and totals are computed server-side from the database, never
  // trusted from the client, so a tampered request can't change the price.
  lineItems.forEach((item) => {
    const product = db.products.find((p) => p.id === item.productId);
    product.stock -= item.qty;
  });

  const order = {
    id: db.nextOrderId++,
    userId: req.user.id,
    items: lineItems,
    total,
    address,
    status: 'Placed',
    createdAt: new Date().toISOString(),
  };
  db.orders.push(order);
  writeDB(db);

  res.status(201).json(order);
});

// GET /api/orders  (current user's order history)
router.get('/', requireAuth, (req, res) => {
  const db = readDB();
  const orders = db.orders
    .filter((o) => o.userId === req.user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(orders);
});

module.exports = router;
