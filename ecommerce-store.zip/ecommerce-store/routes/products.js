const express = require('express');
const { readDB } = require('../data/store');

const router = express.Router();

// GET /api/products?category=Kitchen&q=mug
router.get('/', (req, res) => {
  const { category, q } = req.query;
  const db = readDB();
  let products = db.products;

  if (category) {
    products = products.filter((p) => p.category.toLowerCase() === category.toLowerCase());
  }
  if (q) {
    const needle = q.toLowerCase();
    products = products.filter(
      (p) => p.name.toLowerCase().includes(needle) || p.description.toLowerCase().includes(needle)
    );
  }

  res.json(products);
});

// GET /api/products/:id
router.get('/:id', (req, res) => {
  const db = readDB();
  const product = db.products.find((p) => p.id === Number(req.params.id));
  if (!product) {
    return res.status(404).json({ error: 'Product not found.' });
  }
  res.json(product);
});

module.exports = router;
