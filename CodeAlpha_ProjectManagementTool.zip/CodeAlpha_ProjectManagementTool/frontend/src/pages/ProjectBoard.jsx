import React, { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { io } from 'socket.io-client';
import api from '../api/axios';
import TaskCard from '../components/TaskCard.jsx';
import TaskModal from '../components/TaskModal.jsx';

const COLUMNS = [
  { key: 'todo', label: 'To Do' },
  { key: 'in-progress', label: 'In Progress' },
  { key: 'done', label: 'Done' },
];

export default function ProjectBoard() {
  const { id } = useParams();
  const [project, setProject] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [selectedTask, setSelectedTask] = useState(null);
  const [inviteEmail, setInviteEmail] = useState('');
  const [error, setError] = useState('');
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    const load = async () => {
      const { data } = await api.get(`/projects/${id}`);
      setProject(data.project);
      setTasks(data.tasks);
    };
    load();
  }, [id]);

  // Real-time updates: connect once, join this project's room
  useEffect(() => {
    const s = io(import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000');
    s.emit('project:join', id);
    setSocket(s);

    s.on('task:created', (task) => {
      setTasks((prev) => [task, ...prev.filter((t) => t._id !== task._id)]);
    });
    s.on('task:updated', (task) => {
      setTasks((prev) => prev.map((t) => (t._id === task._id ? task : t)));
    });
    s.on('task:deleted', ({ _id }) => {
      setTasks((prev) => prev.filter((t) => t._id !== _id));
    });

    return () => {
      s.emit('project:leave', id);
      s.disconnect();
    };
  }, [id]);

  const columns = useMemo(() => {
    const map = { todo: [], 'in-progress': [], done: [] };
    tasks.forEach((t) => map[t.status]?.push(t));
    return map;
  }, [tasks]);

  const handleCreateTask = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    try {
      await api.post('/tasks', { title, project: id });
      setTitle('');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create task');
    }
  };

  const handleMove = async (task, status) => {
    await api.put(`/tasks/${task._id}`, { status });
  };

  const handleDelete = async (task) => {
    await api.delete(`/tasks/${task._id}`);
  };

  const handleInvite = async (e) => {
    e.preventDefault();
    if (!inviteEmail.trim()) return;
    try {
      const { data } = await api.post(`/projects/${id}/members`, { email: inviteEmail });
      setProject(data);
      setInviteEmail('');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to add member');
    }
  };

  if (!project) return <p>Loading board...</p>;

  return (
    <div>
      <h1>{project.name}</h1>
      <p className="muted">{project.description}</p>
      {error && <div className="alert-error">{error}</div>}

      <div className="board-toolbar">
        <form onSubmit={handleCreateTask}>
          <input
            placeholder="New task title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <button className="btn btn-primary" type="submit">+ Add Task</button>
        </form>

        <form onSubmit={handleInvite}>
          <input
            placeholder="Invite member by email"
            value={inviteEmail}
            onChange={(e) => setInviteEmail(e.target.value)}
          />
          <button className="btn btn-outline" type="submit">Invite</button>
        </form>
      </div>

      <div className="board">
        {COLUMNS.map((col) => (
          <div className="board-column" key={col.key}>
            <h3>{col.label} ({columns[col.key].length})</h3>
            {columns[col.key].map((task) => (
              <TaskCard
                key={task._id}
                task={task}
                onOpen={setSelectedTask}
                onMove={handleMove}
                onDelete={handleDelete}
              />
            ))}
          </div>
        ))}
      </div>

      {selectedTask && (
        <TaskModal
          task={selectedTask}
          members={project.members}
          socket={socket}
          onClose={() => setSelectedTask(null)}
          onUpdated={(updated) => {
            setTasks((prev) => prev.map((t) => (t._id === updated._id ? updated : t)));
            setSelectedTask(updated);
          }}
        />
      )}
    </div>
  );
}
