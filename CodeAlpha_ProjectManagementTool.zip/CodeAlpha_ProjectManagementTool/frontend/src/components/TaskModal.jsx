import React, { useEffect, useState } from 'react';
import api from '../api/axios';

export default function TaskModal({ task, members, onClose, onUpdated, socket }) {
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description || '');
  const [assignedTo, setAssignedTo] = useState(task.assignedTo?._id || '');

  useEffect(() => {
    const loadComments = async () => {
      const { data } = await api.get(`/comments/task/${task._id}`);
      setComments(data);
    };
    loadComments();
  }, [task._id]);

  useEffect(() => {
    if (!socket) return;
    const handler = (payload) => {
      if (payload.taskId === task._id) {
        setComments((prev) => [...prev, payload.comment]);
      }
    };
    socket.on('comment:created', handler);
    return () => socket.off('comment:created', handler);
  }, [socket, task._id]);

  const handleAddComment = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    const { data } = await api.post('/comments', { text, task: task._id });
    setComments((prev) => [...prev, data]);
    setText('');
  };

  const handleSaveDetails = async () => {
    const { data } = await api.put(`/tasks/${task._id}`, {
      title,
      description,
      assignedTo: assignedTo || null,
    });
    onUpdated(data);
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>✕</button>

        <label>Title</label>
        <input value={title} onChange={(e) => setTitle(e.target.value)} />

        <label>Description</label>
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />

        <label>Assigned to</label>
        <select value={assignedTo} onChange={(e) => setAssignedTo(e.target.value)}>
          <option value="">Unassigned</option>
          {members.map((m) => (
            <option key={m._id} value={m._id}>{m.name}</option>
          ))}
        </select>

        <button className="btn btn-primary" onClick={handleSaveDetails}>Save changes</button>

        <hr />

        <h4>Comments</h4>
        <div className="comment-list">
          {comments.length === 0 && <p className="muted">No comments yet.</p>}
          {comments.map((c) => (
            <div key={c._id} className="comment">
              <strong>{c.author?.name}:</strong> {c.text}
            </div>
          ))}
        </div>

        <form onSubmit={handleAddComment} className="comment-form">
          <input
            placeholder="Write a comment..."
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <button className="btn btn-primary" type="submit">Send</button>
        </form>
      </div>
    </div>
  );
}
