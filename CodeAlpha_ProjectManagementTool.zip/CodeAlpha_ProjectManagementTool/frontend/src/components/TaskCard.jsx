import React from 'react';

const statusOrder = ['todo', 'in-progress', 'done'];

export default function TaskCard({ task, onOpen, onMove, onDelete }) {
  const currentIndex = statusOrder.indexOf(task.status);

  return (
    <div className="task-card">
      <div className="task-card-header" onClick={() => onOpen(task)}>
        <strong>{task.title}</strong>
        {task.description && <p className="task-desc">{task.description}</p>}
        {task.assignedTo && (
          <span className="task-assignee">👤 {task.assignedTo.name}</span>
        )}
      </div>
      <div className="task-card-actions">
        {currentIndex > 0 && (
          <button onClick={() => onMove(task, statusOrder[currentIndex - 1])}>◀</button>
        )}
        {currentIndex < statusOrder.length - 1 && (
          <button onClick={() => onMove(task, statusOrder[currentIndex + 1])}>▶</button>
        )}
        <button className="danger" onClick={() => onDelete(task)}>✕</button>
      </div>
    </div>
  );
}
