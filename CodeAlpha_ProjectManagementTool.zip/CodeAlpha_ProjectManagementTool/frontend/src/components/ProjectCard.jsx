import React from 'react';
import { Link } from 'react-router-dom';

export default function ProjectCard({ project }) {
  return (
    <Link to={`/projects/${project._id}`} className="project-card">
      <h3>{project.name}</h3>
      <p>{project.description || 'No description'}</p>
      <div className="project-meta">
        <span>{project.members?.length || 0} member(s)</span>
        <span>Owner: {project.owner?.name}</span>
      </div>
    </Link>
  );
}
