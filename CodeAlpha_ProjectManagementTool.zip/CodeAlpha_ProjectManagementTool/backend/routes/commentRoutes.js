const express = require('express');
const Comment = require('../models/Comment');
const Task = require('../models/Task');
const Project = require('../models/Project');
const { protect } = require('../middleware/auth');

const router = express.Router();

async function assertMember(projectId, userId) {
  const project = await Project.findById(projectId);
  if (!project) return null;
  return (
    String(project.owner) === String(userId) ||
    project.members.some((m) => String(m) === String(userId))
  );
}

// @route  GET /api/comments/task/:taskId
router.get('/task/:taskId', protect, async (req, res) => {
  try {
    const task = await Task.findById(req.params.taskId);
    if (!task) return res.status(404).json({ message: 'Task not found' });

    const allowed = await assertMember(task.project, req.user._id);
    if (!allowed) return res.status(403).json({ message: 'Not a member of this project' });

    const comments = await Comment.find({ task: task._id })
      .populate('author', 'name email')
      .sort({ createdAt: 1 });
    res.json(comments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// @route  POST /api/comments   body: { text, task }
router.post('/', protect, async (req, res) => {
  try {
    const { text, task: taskId } = req.body;
    if (!text || !taskId) return res.status(400).json({ message: 'text and task are required' });

    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ message: 'Task not found' });

    const allowed = await assertMember(task.project, req.user._id);
    if (!allowed) return res.status(403).json({ message: 'Not a member of this project' });

    const comment = await Comment.create({ text, task: taskId, author: req.user._id });
    const populated = await comment.populate('author', 'name email');

    const io = req.app.get('io');
    io.to(`project:${task.project}`).emit('comment:created', {
      taskId,
      comment: populated,
    });

    res.status(201).json(populated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
