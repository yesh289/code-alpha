const express = require('express');
const Task = require('../models/Task');
const Project = require('../models/Project');
const { protect } = require('../middleware/auth');

const router = express.Router();

// helper to check membership
async function assertMember(projectId, userId) {
  const project = await Project.findById(projectId);
  if (!project) return null;
  const isMember =
    String(project.owner) === String(userId) ||
    project.members.some((m) => String(m) === String(userId));
  return isMember ? project : false;
}

// @route  POST /api/tasks   body: { title, description, project, assignedTo }
router.post('/', protect, async (req, res) => {
  try {
    const { title, description, project, assignedTo } = req.body;
    if (!title || !project) {
      return res.status(400).json({ message: 'Title and project are required' });
    }

    const allowed = await assertMember(project, req.user._id);
    if (!allowed) return res.status(403).json({ message: 'Not a member of this project' });

    const task = await Task.create({
      title,
      description,
      project,
      assignedTo: assignedTo || null,
      createdBy: req.user._id,
    });

    const populated = await task.populate([
      { path: 'assignedTo', select: 'name email' },
      { path: 'createdBy', select: 'name email' },
    ]);

    const io = req.app.get('io');
    io.to(`project:${project}`).emit('task:created', populated);

    res.status(201).json(populated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// @route  PUT /api/tasks/:id   body: { title, description, status, assignedTo }
router.put('/:id', protect, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });

    const allowed = await assertMember(task.project, req.user._id);
    if (!allowed) return res.status(403).json({ message: 'Not a member of this project' });

    ['title', 'description', 'status', 'assignedTo'].forEach((field) => {
      if (req.body[field] !== undefined) task[field] = req.body[field];
    });

    await task.save();
    const populated = await task.populate([
      { path: 'assignedTo', select: 'name email' },
      { path: 'createdBy', select: 'name email' },
    ]);

    const io = req.app.get('io');
    io.to(`project:${task.project}`).emit('task:updated', populated);

    res.json(populated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// @route  DELETE /api/tasks/:id
router.delete('/:id', protect, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });

    const allowed = await assertMember(task.project, req.user._id);
    if (!allowed) return res.status(403).json({ message: 'Not a member of this project' });

    await task.deleteOne();

    const io = req.app.get('io');
    io.to(`project:${task.project}`).emit('task:deleted', { _id: task._id });

    res.json({ message: 'Task deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
